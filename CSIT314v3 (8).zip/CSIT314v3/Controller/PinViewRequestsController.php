<?php
declare(strict_types=1);

namespace App\Controller;

require_once __DIR__ . '/../Entity/requestEntity.php';

use App\Entity\requestEntity;

final class PinViewRequestsController
{
    public function list(int $userId, ?string $status, int $page, int $perPage): array {
    $ent = new requestEntity();
    return $ent->listRequests($userId, $status, $page, $perPage);
    }

}