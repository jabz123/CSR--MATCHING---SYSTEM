<?php
declare(strict_types=1);

namespace App\Entity;

use PDO;

final class requestEntity
{
    private PDO $pdo;

    public function __construct(
        string $host = '127.0.0.1',
        string $db   = 'csit314',
        string $user = 'root',
        string $pass = ''
    ) {
        $dsn = "mysql:host={$host};dbname={$db};charset=utf8mb4";
        $this->pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }

    public function create(int $userId, string $content, string $location, string $title): bool
    {
        $stmt = $this->pdo->prepare(
            "INSERT INTO requests (user_id, content, location, title) VALUES (:uid, :content, :location, :title)"
        );
        return $stmt->execute([
            ':uid'      => $userId,
            ':content'  => $content,
            ':location' => $location,
            ':title' => $title
        ]);
    }

    public function recentByUser(int $userId, int $limit = 20): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT request_id, content, location, status, created_at, title
             FROM requests
             WHERE user_id = :uid
             ORDER BY request_id DESC
             LIMIT :lim"
        );
        $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function statsByUser(int $userId): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT 
               COUNT(*) AS total,
               SUM(status='open') AS open_count,
               SUM(status='in_progress') AS in_progress_count,
               SUM(status='closed') AS closed_count
             FROM requests
             WHERE user_id = :uid"
        );
        $stmt->execute([':uid' => $userId]);
        $row = $stmt->fetch() ?: ['total'=>0,'open_count'=>0,'in_progress_count'=>0,'closed_count'=>0];
        foreach ($row as $k => $v) $row[$k] = (int)$v;
        return $row;
    }

    // List requests for a user (optional status/search & pagination)
    public function listByUser(
        int $userId,
        ?string $status = null,
        ?string $q = null,
        int $page = 1,
        int $perPage = 10
    ): array {
        $page   = max(1, $page);
        $offset = ($page - 1) * $perPage;

        $where = "FROM requests WHERE user_id = :uid";
        $args  = [':uid' => $userId];

        if ($status !== null && $status !== '') {
            $where .= " AND status = :status";
            $args[':status'] = $status;
        }
        if ($q !== null && $q !== '') {
            $where .= " AND content LIKE :q";
            $args[':q'] = '%'.$q.'%';
        }

        // total
        $stmt = $this->pdo->prepare("SELECT COUNT(*) ".$where);
        $stmt->execute($args);
        $total = (int)$stmt->fetchColumn();

        // page rows
        $stmt = $this->pdo->prepare(
            "SELECT request_id, content, location, status, created_at, title
            $where
            ORDER BY request_id DESC
            LIMIT :lim OFFSET :off"
        );
        foreach ($args as $k => $v) { $stmt->bindValue($k, $v); }
        $stmt->bindValue(':lim', $perPage, \PDO::PARAM_INT);
        $stmt->bindValue(':off', $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return [
            'rows'    => $stmt->fetchAll(),
            'total'   => $total,
            'page'    => $page,
            'perPage' => $perPage,
            'pages'   => (int)ceil($total / $perPage),
        ];
    }

    public function getOneForUser(int $userId, int $requestId): ?array {
        $sql = "SELECT request_id AS id, user_id, content, location, created_at, title
                FROM requests
                WHERE request_id = :rid AND user_id = :uid
                LIMIT 1";
        $stm = $this->pdo->prepare($sql);
        $stm->execute([':rid' => $requestId, ':uid' => $userId]);
        $row = $stm->fetch();
        return $row ?: null;
    }

    /** Update (only if it belongs to user) */
    public function updateForUser(int $userId, int $requestId, string $content, string $location, string $title): bool {
        $sql = "UPDATE requests
                   SET content = :content,
                       location = :location,
                       title = :title
                 WHERE request_id = :rid AND user_id = :uid";
        $stm = $this->pdo->prepare($sql);
        return $stm->execute([
            ':title' => $title,
            ':content'  => $content,
            ':location' => $location,
            ':rid'      => $requestId,
            ':uid'      => $userId,
        ]);
    }
}
