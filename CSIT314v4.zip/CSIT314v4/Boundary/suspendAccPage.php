<?php
declare(strict_types=1);

ini_set('display_errors', '1');
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/../Controller/suspendAccController.php';
use App\Controller\suspendAccController;


$returnUrl = 'view_users.php';  


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (($_SESSION['profile_type'] ?? '') !== 'admin') {
    header('Location: ' . $returnUrl . '?notice=forbidden');
    exit;
}


$targetId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$action   = $_GET['action'] ?? '';
$sFlag    = (isset($_GET['s']) && $_GET['s'] === '1'); // true = suspend, false = activate

if ($action !== 'suspend' || !$targetId) {
    header('Location: ' . $returnUrl . '?notice=invalid');
    exit;
}

if ($targetId === (int)$_SESSION['user_id']) {
    header('Location: ' . $returnUrl . '?notice=self');
    exit;
}

$ctl = new suspendAccController();
$ok  = false;
$why = null;

try {
    $ok = $ctl->suspendUser((int)$targetId, $sFlag);  // bool
    if (!$ok) {
        require_once __DIR__ . '/../Entity/userAccount.php';
        $u = \App\Entity\userAccount::getUserById((int)$targetId); 
        $why = $u ? 'db_update_failed' : 'no_such_id';
    }
} catch (\Throwable $e) {
    $why = 'exception:' . $e->getMessage();
}

$code = $ok ? ($sFlag ? 'suspended' : 'activated') : 'failed';
$q = [
    'notice' => $code,
    'id'     => (string)$targetId,
];
if (!$ok && $why) {
    $q['why'] = $why; 
}

if (!headers_sent()) {
    header('Location: ' . $returnUrl . '?' . http_build_query($q));
    exit;
}

?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Redirecting…</title></head>
<body>
  <p><?= htmlspecialchars($ok ? 'Success' : 'Failed') ?> (<?= htmlspecialchars($code) ?><?= isset($q['why']) ? ', ' . htmlspecialchars($q['why']) : '' ?>)</p>
  <p><a href="<?= htmlspecialchars($returnUrl . '?' . http_build_query($q)) ?>">Back to list</a></p>
</body>
</html>