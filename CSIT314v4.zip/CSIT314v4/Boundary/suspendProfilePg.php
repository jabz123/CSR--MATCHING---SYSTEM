<?php
declare(strict_types=1);

use App\Controller\view_profilesController;
require_once __DIR__ . '/../Controller/view_profilesController.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['profile_type'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$controller = new view_profilesController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$profile = $controller->getProfileDetails($id);

if (!$profile) {
    die('Profile not found.');
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus = $profile['status'] === 'active' ? 'suspended' : 'active';
    if ($controller->updateProfileStatus($id, $newStatus)) {
        $message = "Profile status updated to {$newStatus}.";
        $profile = $controller->getProfileDetails($id);
    } else {
        $message = 'Failed to update status.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Suspend/Activate Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      background: linear-gradient(135deg,#667eea 0%,#764ba2 100%);
      display:flex; align-items:center; justify-content:center;
      min-height:100vh; padding:20px;
    }
    .container {
      background:#fff; border-radius:24px; box-shadow:0 20px 60px rgba(0,0,0,.25);
      max-width:550px; width:100%; padding:40px; text-align:center;
    }
    h2 {
      font-size:1.8rem;
      background:linear-gradient(135deg,#667eea,#764ba2);
      -webkit-background-clip:text; -webkit-text-fill-color:transparent;
      margin-bottom:20px;
    }
    p { color:#333; margin-bottom:25px; font-size:1.1rem; }
    form { display:inline-block; }
    button {
      padding:15px 30px;
      border:none;
      border-radius:14px;
      font-size:1rem;
      font-weight:700;
      color:#fff;
      cursor:pointer;
      transition:all .3s ease;
    }
    .btn-danger { background:linear-gradient(135deg,#ef4444,#dc2626); }
    .btn-success { background:linear-gradient(135deg,#22c55e,#16a34a); }
    button:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(0,0,0,.2); }
    .msg { margin-top:20px; font-weight:600; }
    .back { margin-top:30px; }
    .link-btn {
      text-decoration:none; border:2px solid #667eea; color:#667eea;
      padding:10px 20px; border-radius:14px; transition:.3s;
    }
    .link-btn:hover { background:#667eea; color:#fff; }
  </style>
</head>
<body>
  <div class="container">
    <h2><?= ucfirst($profile['status']) ?> Profile</h2>
    <p>Profile Type: <strong><?= htmlspecialchars($profile['profile_type']) ?></strong></p>
    <p>Current Status: <strong><?= htmlspecialchars($profile['status']) ?></strong></p>

    <form method="POST">
      <?php if ($profile['status'] === 'active'): ?>
        <button type="submit" class="btn-danger">Suspend Profile</button>
      <?php else: ?>
        <button type="submit" class="btn-success">Activate Profile</button>
      <?php endif; ?>
    </form>

    <?php if ($message): ?>
      <div class="msg"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="back">
      <a href="view_profiles.php" class="link-btn">Back to Profiles</a>
    </div>
  </div>
</body>
</html>
