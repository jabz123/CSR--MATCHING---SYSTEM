<?php
declare(strict_types=1);

// MAX DEBUG — keep while fixing
ini_set('display_errors', '1');
ini_set('log_errors', '1');
error_reporting(E_ALL);

session_start();

// 0) Checkpoint
echo "<!-- checkpoint: start -->\n";

// 1) Role guard (PIN must be EXACT capitalization)
if (empty($_SESSION['user_id'])) {
    echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>SESSION missing user_id. Redirecting to login…</pre>";
    header('Location: login.php'); exit;
}
if (($_SESSION['profile_type'] ?? '') !== 'pin') {
    echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>SESSION profile_type is not 'PIN'. Got: "
         . htmlspecialchars((string)($_SESSION['profile_type'] ?? 'NULL'))
         . " → redirecting to login…</pre>";
    header('Location: login.php'); exit;
}

echo "<!-- checkpoint: role ok -->\n";

// 2) CSRF token
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(32));
}

// 3) Handle POST (instrumented)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'create_request') {
    echo "<!-- checkpoint: entered POST handler -->\n";

    $content  = trim((string)($_POST['content'] ?? ''));
    $location = trim((string)($_POST['location'] ?? ''));
    $title = trim((string)($_POST['title'] ?? ''));
    $csrfOk   = !empty($_POST['_csrf']) && hash_equals($_SESSION['_csrf'] ?? '', (string)$_POST['_csrf']);

    if (!$csrfOk) {
        $_SESSION['flash'] = '❌ Invalid submission. Please try again.';
    } elseif ($location === '' || mb_strlen($location) > 255 || $content === '' || mb_strlen($content) > 4000 || $title === '') {
        $_SESSION['flash'] = '⚠️ Please enter a valid location and request.';
    } else {
        $ctlPath = __DIR__ . '/../Controller/PinCreateRequestController.php';
        if (!file_exists($ctlPath)) {
            echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>Controller file missing: "
                 . htmlspecialchars($ctlPath) . "</pre>";
            exit;
        }
        require_once $ctlPath;

        if (!class_exists('\\App\\Controller\\PinCreateRequestController')) {
            echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>Controller class not found: \\App\\Controller\\PinCreateRequestController</pre>";
            exit;
        }

        try {
            $controller = new \App\Controller\PinCreateRequestController();
            $ok = $controller->create((int)$_SESSION['user_id'], $content, $location, $title);
            $_SESSION['flash'] = $ok ? '✅ Request created successfully.' : '❌ Could not create request.';
        } catch (\Throwable $e) {
            echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>Controller EXCEPTION: "
                 . htmlspecialchars($e->getMessage()) . "\nFile: " . $e->getFile() . ':' . $e->getLine() . "</pre>";
            exit;
        }
    }

    header('Location: pin_dashboard.php'); exit; // PRG
}

// 4) Load Entity (with checks), fetch data
$entPath = __DIR__ . '/../Entity/requestEntity.php';
if (!file_exists($entPath)) {
    echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>Entity file missing: "
         . htmlspecialchars($entPath) . "</pre>";
    exit;
}
require_once $entPath;

if (!class_exists('\\App\\Entity\\requestEntity')) {
    echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>Entity class not found: \\App\\Entity\\requestEntity</pre>";
    exit;
}

try {
    $repo     = new \App\Entity\requestEntity();
    $userId   = (int)$_SESSION['user_id'];
    $userName = htmlspecialchars($_SESSION['name'] ?? 'pin');

    // These calls can throw—surround with try
    $stats    = $repo->statsByUser($userId);
    $requests = $repo->recentByUser($userId, 8);

    // Basic structure sanity
    if (!is_array($stats))  { throw new \RuntimeException('statsByUser did not return array'); }
    if (!is_array($requests)) { throw new \RuntimeException('recentByUser did not return array'); }

} catch (\Throwable $e) {
    echo "<pre style='color:#b00;background:#fee;padding:10px;border:1px solid #fbb'>Entity/DB EXCEPTION: "
         . htmlspecialchars($e->getMessage()) . "\nFile: " . $e->getFile() . ':' . $e->getLine() . "</pre>";
    exit;
}

echo "<!-- checkpoint: data loaded ok -->\n";
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>PIN Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 50%,#d946ef 100%);color:#111827}
  .wrap{max-width:1100px;margin:28px auto;padding:0 18px}
  .topbar{background:rgba(255,255,255,.95);backdrop-filter:blur(8px);border-radius:20px;padding:18px 22px;
          display:flex;justify-content:space-between;align-items:center;box-shadow:0 10px 35px rgba(0,0,0,.15)}
  .brand{display:flex;align-items:center;gap:12px}
  .logo{width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,#6366f1,#8b5cf6);
        display:grid;place-items:center;color:#fff;font-size:22px}
  .title{font-weight:800;color:#4f46e5;font-size:22px}
  .logout{padding:10px 16px;border:0;border-radius:12px;background:linear-gradient(135deg,#ef4444,#dc2626);
          color:#fff;cursor:pointer;font-weight:800;font-size: 16px}
  .hero{margin:26px 0;background:rgba(255,255,255,.96);border-radius:24px;padding:28px;box-shadow:0 12px 40px rgba(0,0,0,.18)}
  .hero h1{margin:0 0 8px;font-size:36px}
  .muted{color:#6b7280}
  .cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;margin-top:22px}
  .card{background:#fff;border-radius:20px;padding:20px;box-shadow:0 10px 30px rgba(0,0,0,.15)}
  .card h3{margin:0 0 6px;font-size:20px}
  .btn{display:inline-block;padding:12px 18px;border-radius:12px;border:0;cursor:pointer;font-weight:800;color:#fff;
       background:linear-gradient(135deg,#6366f1,#8b5cf6);text-decoration:none;box-shadow:0 8px 20px rgba(99,102,241,.35);font-size: 14px}
  .btn:focus,.btn:hover{transform:translateY(-1px)}
  .btn-secondary{background:linear-gradient(135deg,#14b8a6,#0ea5e9)}
  .btn-gray{background:linear-gradient(135deg,#9ca3af,#6b7280)}
  .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:22px}
  table{width:100%;border-collapse:collapse}
  th,td{padding:12px;border-bottom:1px solid #e5e7eb;text-align:left;vertical-align:top}
  th{background:#f8fafc;font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:#6b7280}
  .status{display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700}
  .status.open{background:#e0e7ff;color:#3730a3}
  .status.in_progress{background:#fef3c7;color:#92400e}
  .status.closed{background:#dcfce7;color:#065f46}
  .stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:8px}
  .stat{background:#fff;border-radius:16px;padding:14px;text-align:center;box-shadow:0 8px 24px rgba(0,0,0,.12)}
  .big{font-size:28px;font-weight:900;color:#4f46e5}
  .flash{margin:16px 0;background:#ecfdf5;border:1px solid #10b981;color:#065f46;padding:12px 16px;border-radius:12px;font-weight:700}
  /* Modal */
  .modal{position:fixed;inset:0;background:rgba(0,0,0,.35);display:none;align-items:center;justify-content:center;padding:16px}
  .modal.open{display:flex}
  .sheet{background:#fff;border-radius:16px;max-width:560px;width:100%;padding:40px;box-shadow:0 20px 60px rgba(0,0,0,.35)}
  .sheet h3{margin:0 0 10px}
  label{display:block;margin:10px 0 6px;font-weight:700;color:#374151}
  input[type=text], textarea{width:100%;padding:10px;border:1px solid #e5e7eb;border-radius:10px;font:inherit}
  textarea{min-height:120px}
  .row{display:flex;gap:10px;justify-content:flex-end;margin-top:14px}
  .btn-outline{background:#fff;color:#374151;border:1px solid #e5e7eb}
  @media (max-width:980px){.cards{grid-template-columns:1fr}.grid-2{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}}
</style>
</head>
<body>
<div class="wrap">

  <!-- Topbar -->
  <div class="topbar">
    <div class="brand"><div class="logo">🤝</div><div class="title">PIN Dashboard</div></div>
    <div>Welcome, <strong><?= $userName ?></strong>
      &nbsp;&nbsp;<a href="logout.php"><button class="logout">Logout</button></a></div>
  </div>

  <?php if (!empty($_SESSION['flash'])): ?>
    <div class="flash"><?= htmlspecialchars($_SESSION['flash']) ?></div>
    <?php unset($_SESSION['flash']); ?>
  <?php endif; ?>

  <!-- Hero -->
  <div class="hero">
    <h1>Manage Your Requests</h1>
    <p class="muted">Create a new help request, and track the progress of your existing ones.</p>

    <!-- Stats -->
    <div class="stats">
      <div class="stat"><div class="muted">Total</div><div class="big"><?= (int)$stats['total'] ?></div></div>
      <div class="stat"><div class="muted">Open</div><div class="big"><?= (int)$stats['open_count'] ?></div></div>
      <div class="stat"><div class="muted">In Progress</div><div class="big"><?= (int)$stats['in_progress_count'] ?></div></div>
      <div class="stat"><div class="muted">Closed</div><div class="big"><?= (int)$stats['closed_count'] ?></div></div>
    </div>

    <!-- Action Cards (like your admin screenshot) -->
    <div class="cards">
      <div class="card">
        <h3>Create Request</h3>
        <p class="muted">Describe the help you need and where you are.</p>
        <button class="btn" onclick="openCreate()">Create Request</button>
      </div>

      <div class="card">
        <h3>My Requests</h3>
        <p class="muted">View your recent requests and their status.</p>
        <!-- <a class="btn btn-secondary" href="#recent">Manage Requests</a> -->
        <a class="btn btn-secondary" href="pin_view_requests.php">Manage Requests</a>
      </div>

      <div class="card">
        <h3>Profile</h3>
        <p class="muted">Update your contact details and preferences.</p>
        <a class="btn btn-gray" href="profile.php">Manage Profile</a>
      </div>
    </div>
  </div>

  <!-- Recent + (optional) other panel -->
  <div class="grid-2" id="recent">
    <div class="card" style="grid-column:1 / -1;">
      <h2 style="margin:0 0 10px;">Recent Requests</h2>
      <div style="overflow:auto;max-height:420px;">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Request</th>
              <th>Location</th>
              <th>Status</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($requests)): ?>
              <tr><td colspan="5">No requests yet.</td></tr>
            <?php else: foreach ($requests as $r): ?>
              <tr>
                <td><?= (int)$r['request_id'] ?></td>
                <td><?= nl2br(htmlspecialchars($r['content'])) ?></td>
                <td><?= htmlspecialchars($r['location']) ?></td>
                <?php $s = strtolower((string)$r['status']); ?>
                <td><span class="status <?= htmlspecialchars(str_replace('-', '_', $s)) ?>"><?= htmlspecialchars($r['status']) ?></span></td>
                <td><?= htmlspecialchars((string)$r['created_at']) ?></td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>

<!-- Create Request Modal -->
<div class="modal" id="createModal" aria-hidden="true">
  <div class="sheet">
    <h3>Create a Help Request</h3>
    <form method="post" action="pin_dashboard.php">
      <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">
      <input type="hidden" name="action" value="create_request">
      <label for="title">Title</label>
      <input type="text" id="title" name="title" maxlength="255" placeholder="e.g., Collect medicine" required>
      <label for="location">Location</label>
      <input type="text" id="location" name="location" maxlength="255" placeholder="e.g., Block 123, Singapore" required>
      <label for="content">What help do you need?</label>
      <textarea id="content" name="content" maxlength="4000" placeholder="Describe your request..." required></textarea>
      <div class="row">
        <button type="button" class="btn btn-outline" onclick="closeCreate()">Cancel</button>
        <button type="submit" class="btn">Submit Request</button>
      </div>
    </form>
  </div>
</div>

<script>
  const modal = document.getElementById('createModal');
  function openCreate(){ modal.classList.add('open'); }
  function closeCreate(){ modal.classList.remove('open'); }
  // close on backdrop click
  modal.addEventListener('click', e => { if (e.target === modal) closeCreate(); });
</script>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('createModal');
    if (modal) modal.classList.remove('open'); // force close overlay
  });
</script>
</body>
</html>
