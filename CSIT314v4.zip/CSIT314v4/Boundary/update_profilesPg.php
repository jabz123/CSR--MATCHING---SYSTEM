<?php
declare(strict_types=1);

use App\Controller\view_profilesController;
require_once __DIR__ . '/../Controller/view_profilesController.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['profile_type'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$controller = new view_profilesController();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$profile = $controller->getProfileDetails($id);

if (!$profile) {
    die('Profile not found.');
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $profile_type = trim($_POST['profile_type']);
    if ($controller->updateProfileType($id, $profile_type)) {
        $message = 'Profile updated successfully!';
        $profile = $controller->getProfileDetails($id);
    } else {
        $message = 'Failed to update profile. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Update Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      background: linear-gradient(135deg,#667eea 0%,#764ba2 100%);
      display:flex; align-items:center; justify-content:center;
      min-height:100vh; padding:20px;
    }
    .container {
      background:#fff; border-radius:24px; box-shadow:0 20px 60px rgba(0,0,0,.25);
      max-width:550px; width:100%; padding:40px;
    }
    h2 {
      text-align:center;
      background:linear-gradient(135deg,#667eea,#764ba2);
      -webkit-background-clip:text; -webkit-text-fill-color:transparent;
      margin-bottom:20px;
    }
    form { display:grid; gap:20px; }
    label { font-weight:600; color:#333; margin-bottom:8px; display:block; }
    select {
      padding:18px; border-radius:14px; border:2px solid #d0d0d0;
      font-size:1.1rem; width:100%;
    }
    button {
      padding:18px;
      border:none;
      border-radius:14px;
      background:linear-gradient(135deg,#667eea,#764ba2);
      color:#fff;
      font-weight:700;
      cursor:pointer;
      transition:all .3s ease;
    }
    button:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(102,126,234,0.4); }
    .msg { margin-top:20px; text-align:center; font-weight:600; }
    .success { color:#16a34a; }
    .error { color:#dc2626; }
    .back { text-align:center; margin-top:25px; }
    .link-btn {
      text-decoration:none; border:2px solid #667eea; color:#667eea;
      padding:10px 20px; border-radius:14px; transition:.3s;
    }
    .link-btn:hover { background:#667eea; color:#fff; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Update Profile Type</h2>

    <?php if ($message): ?>
      <div class="msg <?= strpos($message, 'successfully') ? 'success' : 'error' ?>">
        <?= htmlspecialchars($message) ?>
      </div>
    <?php endif; ?>

    <form method="POST">
      <label for="profile_type">Profile Type</label>
      <select name="profile_type" id="profile_type" required>
        <option value="">-- Select Type --</option>
        <option value="admin" <?= $profile['profile_type'] === 'admin' ? 'selected' : '' ?>>Admin</option>
        <option value="csr" <?= $profile['profile_type'] === 'csr' ? 'selected' : '' ?>>CSR Rep</option>
        <option value="pin" <?= $profile['profile_type'] === 'pin' ? 'selected' : '' ?>>PIN</option>
        <option value="platform" <?= $profile['profile_type'] === 'platform' ? 'selected' : '' ?>>Platform</option>
      </select>

      <button type="submit">Update Profile</button>
    </form>

    <div class="back">
      <a href="view_profiles.php" class="link-btn">Back to Profiles</a>
    </div>
  </div>
</body>
</html>
