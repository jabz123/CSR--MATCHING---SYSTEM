<?php
declare(strict_types=1);

namespace App\Controller;

use App\Entity\userAccount;
require_once __DIR__ . '/../Entity/userAccount.php';

final class LoginController
{
    /**
     * Authenticates a user login request.
     * Returns true if valid, false otherwise.
     */
    public function authenticate(string $name, string $password): bool
    {
        // Boundary already cleaned inputs
        $user = userAccount::verifyUser($name, $password);

        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['profile_type'] = $user['profile_type'];
            $_SESSION['status'] = $user['status'];
            return true;
        }

        return false;
    }
}
