<?php
declare(strict_types=1);

namespace App\Controller;

use App\Entity\userAccount;

require_once __DIR__ . '/../Entity/userAccount.php';

final class view_usersController
{
    /** Fetch all users */
    public function getAllUsers(): array {
        return userAccount::getAllUsers();
    }

    /** Fetch details for a specific user */
    public function viewUserDetails(int $id): ?array {
        return userAccount::getUserById($id);
    }

    /** Search users by name or profile type */
    public function searchUsers(string $term): array {
        return userAccount::searchUsers($term);
    }
}
