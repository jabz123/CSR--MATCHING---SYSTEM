<?php
declare(strict_types=1);

namespace App\Controller;

require_once dirname(__DIR__) . '/Entity/userAccount.php'; // remove if using Composer autoload
use App\Entity\userAccount;

class CreateAccountController
{
    /**
     * Boundary passes trimmed $name/$profileType and HASHED $password.
     * Returns [bool $ok, string $message]
     */
    public function handleCreateAccount(string $name, string $password, string $profileType): array
    {
        if ($name === '' || $password === '' || $profileType === '') {
            return [false, 'All fields are required.'];
        }

        // (Optional) normalize/guard role — safe even if Boundary already did it
        $role = strtolower($profileType);
        // $allowed = ['admin','csr','pin','platform'];
        // if (!in_array($role, $allowed, true)) return [false, 'Invalid profile type.'];

        // Call Entity POSITIONALLY (avoids named-arg issues)
        $created = userAccount::createAccount($name, $password, $role);

        return $created ? [true, ''] : [false, 'Error creating account.'];
    }
}
