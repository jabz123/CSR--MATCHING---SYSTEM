<?php
declare(strict_types=1);

namespace App\Controller;

require_once __DIR__ . '/../Entity/requestEntity.php';

final class PinViewRequestsController
{
    /** @var \App\Entity\requestEntity */
    private \App\Entity\requestEntity $repo;

    public function __construct(?\App\Entity\requestEntity $repo = null)
    {
        $this->repo = $repo ?? new \App\Entity\requestEntity();
    }

    public function listByUser(
        int $userId,
        ?string $status = null,
        ?string $q = null,
        int $page = 1,
        int $perPage = 10
    ): array {
        return $this->repo->listByUser($userId, $status, $q, $page, $perPage);
    }
}
