<?php
declare(strict_types=1);

namespace App\Controller;

// make sure the Entity file is loaded (no composer autoloader here)
require_once __DIR__ . '/../Entity/requestEntity.php';

final class PinCreateRequestController
{
    /** @var \App\Entity\requestEntity */
    private \App\Entity\requestEntity $repo;

    public function __construct(?\App\Entity\requestEntity $repo = null)
    {
        // ✅ use the Entity namespace, not App\Controller
        $this->repo = $repo ?? new \App\Entity\requestEntity();
    }

    public function create(int $userId, string $content, string $location, string $title): bool
    {
        if ($userId <= 0 || $content === '' || $location === '' || $title === '') {
            return false;
        }
        return $this->repo->create($userId, $content, $location, $title);
    }
} 
